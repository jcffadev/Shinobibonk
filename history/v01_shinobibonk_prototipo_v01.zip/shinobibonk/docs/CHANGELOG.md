# CHANGELOG

## 2026-11-05 — v0.1

- Consolidado escopo: browser primeiro; Windows/Android/iOS depois; coop até quatro jogadores; clãs e rankings por jogador, clã, personagem, modo e temporada.
- Requisito crítico de desempenho: meta de 240 FPS fluidos; estresse com 1.400 inimigos e muitos hits; ainda sem validação.
- Definidos quatro heróis iniciais: Naruto, Gaara, Madara e Hashirama.
- Documentados Naruto clássico → Shippuden, equipes, evoluções, passivas únicas, Lee vs Guy, compartilhamento controlado de técnicas, Gaara/Rasa/Shinki, selamento, ninjas de vilas e Bijuu candidatas a chefes.
- Documentados elementos, Taijutsu como Normal, Genjutsu como Mental, status, dano aditivo e multiplicadores [x].
- Adicionadas pílulas Akimichi como sistema de buffs temporários.
- Criado protótipo HTML/Canvas local jogável com arte geométrica original; sem multiplayer e sem benchmark de 240 FPS.
