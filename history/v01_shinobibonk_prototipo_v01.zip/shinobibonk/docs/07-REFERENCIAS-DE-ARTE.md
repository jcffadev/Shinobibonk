# 07 — Referências de pixel art (pesquisa inicial)

**Pesquisa de fontes, não autorização de uso.**

- https://nogardlab.itch.io/naruto-themed-sprites-16x16 — pacote anunciado com 25 sprites 16×16, incluindo Naruto, Gaara, Madara, Might Guy, Minato e shinobis genéricos. Disponível por contribuição voluntária. **Licença de uso e direitos sobre a franquia não confirmados.** Não incluído no protótipo.
- https://itch.io/game-assets/tag-naruto/tag-pixel-art — catálogo de pixel arts relacionados a Naruto. Verificar cada licença separadamente.
- https://perspectibia.itch.io/substitution-jutsu-effect — efeito de substituição com licença publicada para uso em jogos, mas proibição de redistribuir o asset isoladamente; uso de marca/personagens exige avaliação separada.

Decisão: protótipo v0.1 utiliza desenhos geométricos procedurais próprios para não distribuir arte de terceiros sem licença. Etapa de arte: estabelecer direção visual e produzir spritesheets originais, animações e VFX; publicação com IP Naruto requer autorização adequada.
