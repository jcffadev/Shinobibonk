# 02 — Combate e balanceamento

## Modelo de dano (proposto)

`D = BaseJutsu × (1 + Σ bonusAditivos) × Π(1 + multiplicadorIndependente) × vantagemElemental × critico × mitigacao × variacao`.

- `+20%` soma ao grupo aditivo aplicável. Ex.: +20% geral e +15% Taijutsu => `1.35` para ataque normal.
- `[x]20%` é multiplicador independente `×1.20`; efeitos distintos podem multiplicar, com limites de balanceamento.
- Crítico: chance percentual e multiplicador base 1.60, modificável.
- Defesa: futuro `mitigacao = 100 / (100 + defesaEfetiva)`, evitando redução linear infinita.
- Dano periódico (DoT) usa regras próprias de tick, sem criar um objeto visual por tick.
- PvP, se existir, deverá ter coeficientes próprios; não assumir que builds PvE são equilibradas para PvP.

## Naturezas básicas

Ciclo de superioridade canônico: Fogo > Vento > Raio > Terra > Água > Fogo. **Proposta de jogo:** 1.25x em vantagem e 0.80x em desvantagem. Afinidades secundárias e combinações (Madeira, Gelo, Lava, Tempestade) terão regras específicas. Não confundir dano elemental com vila.

## Taijutsu e Genjutsu

- Taijutsu = categoria Normal/Físico. Proposta: 1.20x contra inimigos especializados em Doton, e Doton pode ter resistência física específica em certas unidades. **Essa vantagem é inventada para gameplay, não cânone.**
- Genjutsu = categoria Mental/Controle: confusão, lentidão, desorientação, interrupção; chefes recebem duração reduzida e resistência crescente a controle, evitando travamento permanente.
- Ninjutsu = dano de natureza, podendo ter status e sinergias.

## Status (proposta)

| Status | Origem | Efeito | Regra de segurança |
|---|---|---|---|
| Queimadura | Fogo | Dano por tempo | Ticks agregados |
| Encharcado | Água | Amplifica Raio | Sem cascata infinita |
| Paralisia | Raio | Interrompe movimento | Resistência em chefes |
| Lentidão/Enraizamento | Terra/Madeira | Reduz mobilidade | Duração máxima |
| Sangramento | Taijutsu/Corte | Dano físico por tempo | Limite de acúmulo |
| Confusão | Genjutsu | Controle/desorientação | Imunidade temporária pós-controle |
| Selamento | Técnicas especiais | Condição de desbloqueio/objetivo | Não equivale a dano puro |

Chance efetiva sugerida: `min(limite, chanceBase + bonusChance - resistenciaAlvo)`; efeitos e duração devem ser avaliados por habilidade. **No protótipo:** queimadura, lentidão e paralisia simplificadas; Genjutsu e selamento ainda não programados.

## Progressão de inimigos

Modelo inicial: `HP(t)=HPbase × (1 + 0.24 × floor(t/35s)) × (1+t/300s)`; densidade sobe ao longo da partida. Futuro: multiplicadores de modo, número de jogadores, elite, chefe e nível da área; reduzir custo de IA por inimigo.

## Balanceamento

O protótipo dá identidade a heróis lendários, mas o jogo final deverá usar custos, passivas, desbloqueios e dificuldade para evitar que Madara/Hashirama invalidem os Genin. Definir métricas: tempo médio de sobrevivência, DPS efetivo, dano recebido, taxa de escolha, variedade de builds e desempenho por personagem e modo.
