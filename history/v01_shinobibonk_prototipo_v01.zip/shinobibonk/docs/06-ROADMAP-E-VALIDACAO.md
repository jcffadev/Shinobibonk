# 06 — Roadmap e validação

## Entrega A — Fatia vertical local (IMPLEMENTADA PARCIALMENTE)

Arena 2D com personagens pixelados procedurais, quatro heróis, jutsus automáticos, inimigos, XP, upgrades, chefes e pílulas. Abrir `game/index.html`. Verificar: escolha de herói, movimento, autoataque, level-up, buffs, ultimate, morte e reinício. Ainda faltam áudio, animações reais, cenário 3D e qualidade de produção.

## Entrega B — Núcleo de alto desempenho

Substituir colisão por grade espacial; usar typed arrays e object pools; separar tick lógico e desenho; instancing de sprites; benchmark 1.400 inimigos com muitos hits; medição p99 e 1% low. Definir motor/browser conforme resultados. Esta etapa é bloqueante antes de expandir conteúdo.

## Entrega C — Conteúdo Naruto clássico

Mapas, vilas, bandanas, inimigos especializados, selamento, progressão Genin, Time 7/8/10/Guy, técnicas de apoio, chefes Bijuu selecionados e evoluções narrativas. Revisão de cânone e propriedade intelectual antes de publicação.

## Entrega D — Online

Autenticação, salvamento, servidor autoritativo, lobby 1–4, coop, reconexão, validação de resultados, clãs, rankings individuais/clã/personagem/modo/temporada.

## Entrega E — Shippuden e plataformas

Versões evoluídas, novas famílias de técnicas, Bijuu, organizações, progressão de mapas; clientes Windows, Android, iOS, controles adaptados e testes cross-play.

## Testes obrigatórios

1. 4 jogadores × 1.400 inimigos × efeitos simultâneos, medindo p95/p99.
2. Pílulas, status, críticos, [x]% e +% sem explosão de recursão.
3. Dificuldade por modo/tamanho de equipe.
4. Resiliência a desconexão e duplicação de recompensa.
5. Segurança de contas, APIs, placares e permissões de clãs.
6. Auditoria de licenças de artes, sons e marcas.

## Pendências

Escolha final de motor; especificação de hardware-alvo para 240 FPS; política de selamento; lista de chefes por mapa; balanceamento de Genin vs lendários; regras de pílulas; arte licenciada ou universo original; orçamento de servidores.
