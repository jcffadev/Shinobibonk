# 05 — Arquitetura, performance e multiplayer

## Objetivo de desempenho

Meta aspiracional: **240 FPS estáveis**, orçamento médio de **4,17 ms/frame**, incluindo combates com muitos hits. Cenário de estresse: **1.400+ inimigos**, quatro jogadores, status, morte, coleta e múltiplas habilidades. Monitorar p50/p95/p99 de frametime, 1% low, long tasks, alocação, GC, draw calls, CPU, GPU, memória, largura de banda e RTT. Não prometer 240 FPS em todos os aparelhos; declarar classes de hardware-alvo e opções gráficas.

## Problemas a eliminar

Loop de colisão O(projéteis × inimigos); objeto por número de dano; partículas por hit; alocações no caminho quente; atualização integral de IA por quadro; comunicação por evento de dano; recálculo de HUD por frame; GPU overdraw. **O protótipo v0.1 ainda tem loops O(P×N), logo não serve como prova de performance.**

## Arquitetura alvo

- Simulação desacoplada da apresentação; ticks fixos no servidor (ex.: 20–30 Hz, a testar), interpolação de entidades e renderização até refresh máximo do dispositivo.
- Dados compactos SoA/typed arrays; pools de entidades, projéteis e efeitos.
- Grade espacial uniforme para consultas de proximidade; AoE resolvida em lotes; agregação de dano/DoT por alvo e tick.
- Instancing/batching para sprites e geometria, LOD, culling e efeitos com orçamento dinâmico; números de dano agregados por região.
- Limites de proc e política explícita de interações encadeadas para evitar loops explosivos.
- Testar renderizadores: Godot 4 Web (Compatibility) e Three.js/WebGL 2 com simulação JS/WASM. **Motor não decidido** até benchmark.
- Mobile: budgets distintos para bateria, temperatura, memória e taxa de atualização; mesma lógica autoritativa, fidelidade visual adaptável.

## Multiplayer planejado

Coop solo/duo/trio/squad, até quatro jogadores. Servidor autoritativo controla dano, IA, drops, experiência, selamento, placares e resultados. Clientes enviam inputs, recebem snapshots compactos e interpolam. Predição local com reconciliação quando necessário. WebSocket compatível com browser para protótipo; investigar WebTransport e opções nativas após medir. Instâncias de partida isoladas; reconexão, validação de resultados e proteção contra manipulação. Clãs, matchmaking, contas e ranking em backend separado (PostgreSQL; Redis opcional).

## Rankings

Chaves: temporada, modo, dificuldade, tamanho de equipe, personagem, jogador e clã. Guardar `run_id`, `rules_version`, `build_version`, `seed`, tempo, pontuação e assinatura/validação de servidor. Limitar contribuição de clãs para evitar vantagem apenas por tamanho.

## Critérios de aprovação

Benchmark reproduzível com cena, seed, duração, hardware e navegador documentados. Passar somente se latências e long tasks cumprirem limites acordados. Não usar a RTX 5090 como única máquina de referência. Testar máquina intermediária, notebook integrado e mobile real.
