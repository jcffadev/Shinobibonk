# 01 — Visão e escopo

**Objetivo:** survivor roguelite em arena com movimentação livre, hordas, ataques automáticos, builds combinatórias, status, progressão, chefes, recompensas e, em fases posteriores, coop online até quatro jogadores, clãs e rankings individual, clã, personagem, modo, tamanho da equipe e temporada.

**Plataforma inicial:** navegador. **Futuro:** clientes Windows, Android e iOS com mesma conta, mediante validação técnica. **Meta crítica:** até 240 FPS fluidos em máquinas-alvo, sem travadas de frametime em combate intenso. Meta de estresse: 1.400 inimigos e quatro jogadores simultâneos. Meta **não comprovada**.

**Ambientação:** progressão de Naruto clássico para Shippuden; versões Genin, Chunin/etapas narrativas e evoluções posteriores; personagens não são apenas skins: passivas, ultimates, sinergias e estilos mudam. Exceções de era: Madara e Hashirama são personagens lendários jogáveis desde o protótipo por decisão de produto, não por cronologia.

**Disponibilidade:** Naruto, Gaara, Madara e Hashirama selecionáveis no protótipo. Plano de lançamento: personagens especiais derrotados e selados tornam-se elegíveis ao pool de seleção; ninjas de apoio precisam ser desbloqueados. Inimigos comuns por vila e especialidade. Bijuu como chefes candidatos, pendente decisão de mapas.

**Vila != elemento:** bandana, uniforme e paleta indicam afiliação; ataques e resistências dependem de afinidade individual. Exemplo: Iwagakure tem maior presença de Doton, não exclusividade. Genjutsu = família de controle mental semelhante à função psíquica em RPG; Taijutsu = ataque físico/normal, inclusive para efeitos de itens normais.

**Propriedade intelectual:** personagens, nomes, técnicas e franquia Naruto não são livres por ser fangame gratuito. Sprites encontrados online não podem ser redistribuídos sem verificar licença e autorização. Artes do protótipo são placeholders procedurais; para publicação, obter licenças ou criar universo original sem elementos protegidos.

**Estados:** DEFINIDO = intenção do produto; IMPLEMENTADO = existe no protótipo; PROPOSTO = design sujeito a teste; NÃO VALIDADO = sem benchmark ou teste de produção.
