# 03 — Personagens, habilidades, passivas e relações

**Convenção:** `CANÔNICO` = técnica/associação conhecida na franquia; `ADAPTAÇÃO` = efeito mecânico proposto. Esta é uma **matriz inicial de personagens prioritários**, não um catálogo exaustivo de todos os personagens de Naruto; o elenco total deve ser expandido por saga com pesquisa e revisão.

## Quatro heróis do protótipo (IMPLEMENTADOS em forma simplificada)

| Herói | Era inicial | Passiva exclusiva | Jutsus ativos | Ultimate | Evolução planejada |
|---|---|---|---|---|---|
| Naruto | Genin | Determinação: dano cresce quando HP cai | Shuriken; Rasengan; Clones das Sombras | Combo de clones + Rasengan | Clássico → Shippuden → Modo Sábio → chakra da Kurama (gates narrativos) |
| Gaara | Genin | Armadura de areia: mitigação e contra-ataque | Projéteis de areia; Caixão de areia; Tempestade de areia | Funeral do Deserto | Clássico → Kazekage → guerra |
| Madara | Lendário | Sharingan: crítico e multiplicador crítico | Kunai; Katon; lâminas do Susanoo | Meteorito | Formas históricas e poderes de guerra, a validar |
| Hashirama | Lendário | Vitalidade Senju: regeneração | Taijutsu; estacas Mokuton; floresta Mokuton | Shinsuusenju (representação simplificada) | Modo Sábio e técnicas maiores |

Nota de fidelidade: Naruto Genin com Rasengan representa fase posterior do Naruto clássico; cronologia exata de desbloqueio deverá ser aplicada na campanha, não neste sandbox.

## Times e versões — backlog de conteúdo

| Grupo | Personagens | Identidade e evolução | Técnicas compartilháveis |
|---|---|---|---|
| Time 7 | Naruto, Sasuke, Sakura, Kakashi | Genin → Shippuden, estilos distintos | Ferramentas ninja; substituição; técnicas básicas; ensinamentos do mestre |
| Time Guy | Rock Lee, Neji, Tenten, Might Guy | Taijutsu, Byakugan, armas, Oito Portões | Treino de Taijutsu; ferramentas; estilos de esquiva |
| Time 8 | Hinata, Kiba, Shino, Kurenai | Byakugan, dupla com Akamaru, insetos, Genjutsu | Técnicas de rastreamento e suporte |
| Time 10 | Shikamaru, Ino, Choji, Asuma | Controle de sombras, mente, expansão, lâminas de chakra | Formação Ino–Shika–Cho; suporte tático |
| Areia | Gaara, Temari, Kankuro, Rasa (pai), Shinki (filho adotivo, era posterior) | Areia, vento, marionetes, magnetismo | Manipulação de areia com diferenças de material e passiva |
| Sannin | Jiraiya, Tsunade, Orochimaru | Invocação, cura, serpentes | Invocações, selos e técnicas aprendidas |
| Akatsuki | Itachi, Kisame, Deidara, Sasori, Hidan, Kakuzu, Pain, Konan, Obito | Identidades de chefes e futuros desbloqueáveis | Elementos compartilhados; kits únicos |
| Hokages | Hashirama, Tobirama, Hiruzen, Minato, Tsunade, Kakashi, Naruto | Liderança e técnicas históricas | Ninjutsu básico, invocações e estilos específicos |

## Diferenciação essencial: Lee vs Guy

**Rock Lee:** passiva `Disciplina Implacável` (combo de golpes normais cresce por sequência sem ser atingido); habilidade `Lótus Primária` (agarre/área concentrada); habilidade `Lótus Oculta` (sequência de alto risco com Portões); ultimate `Lótus Oculta aprimorada` (ADAPTAÇÃO para estágio de jogo). Evolução: Genin → Shippuden com melhorias de velocidade, combos e abertura de portões.

**Might Guy:** passiva `Chama da Juventude` (ganho de poder em luta prolongada e proximidade de aliados); `Dynamic Entry`; `Asakujaku`; `Hirudora`; ultimate de estágio final `Yagai / Night Guy` com custo severo e limite narrativo. Abertura dos Oito Portões como sistema de risco próprio. **Não são clones de kit** apesar de ambos serem Taijutsu.

## Compartilhamento controlado de habilidades

Usar tags `natureza`, `clã`, `linhagem`, `mestre`, `escola`, `arma`, `invocação`, `era`, `requisito`. Um jutsu pode ter template comum e variantes individuais:

- **Gaara / Rasa / Shinki:** família de controle granular; Gaara areia comum e defesa automática, Rasa pó de ouro/magnetismo, Shinki areia de ferro/magnetismo. Templates de projétil, prisão e área compartilháveis; custos, alcance, status e ultimates exclusivos.
- **Lee / Guy:** Taijutsu, portões e combos compartilháveis; passivas e ultimates exclusivos.
- **Naruto / Minato / Jiraiya:** Rasengan como família; versões com clones, deslocamento e invocações diferentes.
- **Sasuke / Itachi / Madara / Obito:** Uchiha, Katon, Sharingan; regras distintas de Genjutsu, Susanoo e mobilidade.
- **Hashirama / Yamato:** Mokuton como família; escala, cura, contenção e ultimates distintos.
- **Hinata / Neji:** Byakugan/Jūken, alcance de tenketsu e defesa distintos.
- **Shikamaru / Shikaku:** sombra, controle e armadilhas.
- **Choji / Choza:** expansão corporal, pílulas Akimichi, risco e duração.
- **Tobirama / Minato:** técnicas espaço-temporais distintas; não igualar teletransporte por semelhança visual.

## Inimigos e desbloqueio

Inimigos básicos: ninjas com bandana e uniformes de Konoha, Suna, Kiri, Iwa e Kumo; cada vila tem pools ponderados de elementos, armas e IA, sem exclusividade elemental. Inimigos especiais: rivais, ninjas de elite, invocadores, portadores de Bijuu. Vitória + condição de selamento podem desbloquear personagem de apoio ou jogável, segundo regras narrativas. Bijuu candidatas a chefes, sem decisão definitiva de mapa.

## Cadastro futuro de técnicas

Campos mínimos: `skill_id`, `owner_ids`, `family_id`, `era`, `category` (taijutsu/ninjutsu/genjutsu/suporte), `element`, `base_damage`, `cooldown`, `area`, `projectiles`, `duration`, `status_chance`, `tags`, `ultimate`, `unlock_conditions`, `visual_asset`, `canon_source`, `design_status`.
