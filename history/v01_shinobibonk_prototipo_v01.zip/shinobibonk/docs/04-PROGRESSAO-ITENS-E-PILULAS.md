# 04 — Progressão, builds, itens e pílulas

## Ciclo de partida

Escolha personagem/era → mapa/modo → ondas e jutsus automáticos → XP e upgrades → itens, moedas, pílulas → chefe/selamento → resultados → progressão permanente.

## Atributos globais

Dano aditivo, multiplicador [x], Taijutsu, dano elemental, chance crítica, dano crítico, área, projéteis, duração, recarga, chance de status, velocidade, HP, mitigação, coleta, XP, moedas e sorte. Modificadores de projéteis só afetam técnicas compatíveis; duração não afeta impactos instantâneos. Recarga tem piso, área e projéteis têm tetos de custo visual. Itens devem exibir se o bônus é `+%` ou `[x]%`.

## Upgrades IMPLEMENTADOS

Força Ninja (+15% dano), Poder Interior ([x]10%), Expansão (+18% área), Duplicação (+1 projétil), Persistência (+20% duração), Selos Rápidos (-9% recarga, teto 65%), Precisão (+6 p.p. crítico), Afinidade (+8 p.p. status), Passos Leves (+8% velocidade), Resistência (+20 HP), Estudo Ninja (+18% XP), Bolsa Ninja (+20% moedas), Percepção (+20% coleta), Treinamento Completo (+5% múltiplos atributos), Treino de Jutsu (+1 nível de cada jutsu), Punhos de Ferro (+20% Taijutsu), Natureza de Chakra (+15% elemental).

## Itens futuros (PROPOSTOS)

| Item | Família | Efeito |
|---|---|---|
| Pergaminho de Treinamento | Global | + atributos básicos em pequena escala |
| Peso de Tornozelo | Taijutsu | + dano normal, - velocidade antes de remover pesos |
| Bolsa de Ferramentas | Projéteis | + projéteis de armas elegíveis |
| Pergaminho de Selos | Recarga | - recarga de Ninjutsu |
| Pergaminho de Invocação | Duração | + duração de invocações |
| Pergaminho de Chakra | Elemental | + dano de natureza |
| Bolsa de Ryo | Economia | + moedas |
| Pergaminho de Estudo | Experiência | + XP |
| Olho Sensorial | Coleta | + raio de coleta |
| Talismã de Proteção | Defesa | + HP/mitigação |
| Marca de Precisão | Crítico | + chance e dano crítico |
| Selo de Amplificação | Especial | [x] dano com custo de recarga |

## Pílulas Akimichi

**Canônicas como inspiração:** três pílulas coloridas do clã Akimichi, com riscos graves na narrativa. **Mecânica adaptada:** buffs temporários de 12 segundos para um protótipo arcade; não equivalem aos efeitos canônicos.

- **Verde:** +30% velocidade e 20% menor intervalo de ativação.
- **Amarela:** [x]35% dano; área ampliada será acrescentada.
- **Vermelha:** [x]80% dano com drenagem de HP; no futuro, debuff após efeito e limite de uso.

No protótipo, teclas 1/2/3 ativam pílulas sem custo/estoque — **apenas para teste**. Versão final: drops, estoque, raridade, riscos, sinergia exclusiva de Choji/Choza e regras de acumulação. Não devem ser obrigatórias para todas as builds.

## Progressão persistente planejada

Desbloqueios de personagens, eras, jutsus, itens e auxiliares; pesquisa na academia; níveis de conta e conquistas; temporadas; metas por modo e personagem. Não implementar progressão permanente de poder sem medir impacto nos rankings. Diferenciar modo normal, desafio e competitivo.
