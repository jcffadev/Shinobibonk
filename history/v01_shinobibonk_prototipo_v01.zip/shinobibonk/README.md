# ShinobiBonk — Protótipo v0.1

Jogo experimental **não oficial**, inspirado em mecânicas de survivor/roguelite. Naruto e personagens relacionados são propriedades de seus titulares. **Não há licença de distribuição dos personagens.** Esta versão é uma demonstração local, sem monetização, com sprites geométricos originais provisórios.

## Executar

Abra `game/index.html` em Chrome, Edge ou Firefox moderno. Não requer instalação, servidor, bibliotecas externas ou internet. Para servir localmente, na pasta raiz: `python -m http.server 8000` e acesse `http://localhost:8000/game/`.

## Controles

WASD/setas: movimento; espaço: ultimate; 1/2/3: pílula Akimichi verde/amarela/vermelha; P: pausa; upgrades por clique ou teclas 1–3 na tela de nível.

## O que está implementado

Quatro personagens selecionáveis (Naruto, Gaara, Madara, Hashirama); três ataques automáticos por personagem; passivas distintas; ultimate; sete categorias de dano/afinidade; efeitos queimadura, lentidão e paralisia; Taijutsu com bônus contra inimigos de terra; XP, nível, 17 upgrades, moedas, coleta, pílulas temporárias, inimigos escaláveis e chefes periódicos; HUD e FPS aproximado.

## Limitações explícitas

**Não implementados:** multiplayer real, contas, clãs, rankings, mapas por saga, selamento, desbloqueios persistentes, personagens evoluídos, sprites de anime licenciados, efeitos de áudio, banco de dados e servidores. **240 FPS com 1.400 inimigos não foram validados.** O protótipo prioriza demonstrar regras e loops; os loops de colisão atuais são O(projéteis × inimigos) e precisarão ser substituídos por indexação espacial e estruturas compactas antes do benchmark de alta densidade. O FPS mostrado é uma aproximação, não um perfilador.

## Documentos

- `docs/01-VISAO-E-ESCOPO.md` — escopo e decisões.
- `docs/02-COMBATE-E-BALANCEAMENTO.md` — matemática e status.
- `docs/03-PERSONAGENS-E-HABILIDADES.md` — roster, passivas, relações e progressão.
- `docs/04-PROGRESSAO-ITENS-E-PILULAS.md` — builds, itens, pílulas e desbloqueios.
- `docs/05-ARQUITETURA-PERFORMANCE.md` — arquitetura para 240 FPS e multiplayer.
- `docs/06-ROADMAP-E-VALIDACAO.md` — entregas e testes.
- `docs/07-REFERENCIAS-DE-ARTE.md` — pesquisa de sprites e licenças.
- `docs/CHANGELOG.md` — registro de alterações.

## Observação

Nomes e efeitos de técnicas têm adaptações para gameplay. Valores são **balanceamento inicial experimental**, não retrato canônico de poder. Consulte a documentação antes de alterar regras.
