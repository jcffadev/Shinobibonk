# ShinobiBonk — especificação consolidada (05/11/2026)

## Visão
Roguelite de sobrevivência inspirado em PokéBonk/Megabonk. Browser primeiro; Windows, Android e iOS futuramente. Cooperativo para até 4 jogadores, clãs, rankings individuais, por clã, personagem, modo e dificuldade. Servidor autoritativo e validação de resultados serão necessários para competição.

## Requisitos de desempenho
Meta aspiracional 240 FPS (4,17 ms/frame) em máquina de referência, sem stutter perceptível durante explosões de hits e até 1.400 inimigos. Medir frame times p95/p99, 1% low, CPU, GPU, memória e simulação; sem garantia antes de testes. Separar renderização, simulação e rede; pooling, batching, spatial hashing e agregação de efeitos de dano.

## Personagens
Iniciais Naruto, Gaara, Madara e Hashirama. Passivas individuais; jutsus e ultimates próprios. Progressão Naruto clássico até Shippuden, times de ninjas e versões evoluídas; Lee e Guy compartilham Taijutsu mas têm identidades distintas. Gaara, Rasa e Shinki compartilham família de técnicas de areia. Shisui é NPC inicialmente, jogável futuramente.

## Controles
WASD mover; mouse girar câmera, clique esquerdo selecionar; Espaço pular; Shift esquivar; E interagir; 1–4 jutsus, slot 4 desbloqueável com Ryō; R Ultimate manual; Y liga/desliga Ultimate automática. Todos acumulam Chakra para Ultimate, inclusive Taijutsu.

## Economia e pool
Ryō = moeda monetária permanente; Chakra = recurso de Ultimate. Drops de XP, Ryō e Chakra, multiplicados por dificuldade. Ryō também vem de progresso, marcos e recompensas diárias (estas últimas ainda não implementadas). Desbloqueios adicionam itens/jutsus/pílulas ao pool; planejar destaca, arquivar exclui das escolhas normais. Sorte influencia raridades comum, incomum, raro, épico, lendário; colar de Hashirama/Tsunade dá Sorte. Atributos não têm teto rígido de progressão de nível, mas valores internos precisam ser protegidos de overflow.

## Combate
Bônus aditivos +% e multiplicadores [x]%. Elementos e Taijutsu (normal), Genjutsu (mental). Status: fogo/queimadura, gelo/congelamento, paralisia, veneno, lentidão, desorientação. DoT e DPS medidos separadamente. Sharingan permite copiar técnicas compatíveis, com bônus aditivo para copiadas e multiplicativo para afinidades próprias (futuro). Habilidades têm dano, área, projéteis, duração, recarga, chance de status. Pílulas Akimichi e Saquê do Punho Bêbado lendário.

## Eventos
Sapos Sábios: altares de buffs; Orochimaru: maldição aumenta dificuldade e concede nível/recompensa; Guy: treinamento com metas de abates e proteção de área; caça-níquel: gasta Ryō e pode causar dano ou recompensar. Ichiraku: fusão de duas técnicas, preservando investimento e permitindo técnica comum/Ultimate alternativa (futuro). Shisui: duplicação paga de habilidades comuns/pílulas, excluindo Ultimate natural (futuro).

## Estágios
Genin → Chunin → Jonin → Kage, desbloqueio sequencial, recompensa e escalonamento. 3 estágios de ~10 minutos, depois chefe final Kyūbi com até 10 minutos. Portais dimensionais de Kaguya entre fases; cenários procedurais temáticos de vilas. Inimigos crescem em número, vida, ataque, velocidade, resistências elementais, física e a status; runs finitas.

## Relatório
Tempo, abates, DPS médio e ao longo do tempo, dano por jutsu/item/DoT, hits, status, itens e raridades, XP, Ryō, build final, eventos e comparações históricas. A v0.3 implementa apenas resumo básico e barras de dano por habilidade.

## Implementado na v0.3
Arena 2D rotacionável, quatro ninjas, habilidades e Ultimates, alguns status, 24 itens, 13 pílulas, NPCs básicos, pool/planejamento, persistência local, escalonamento simplificado, Kyūbi, relatório básico. **Não declarar concluídos** multiplayer, mapa procedural, pixel art detalhada, fusões, eventos de defesa, ranking, árvores passivas, progressão de personagens ou 240 FPS.

## Direitos e arte
Fangame gratuito não garante permissão de distribuição. Não incorporar sprites de terceiros sem licença. Pixel art procedural temporária no protótipo; artes autorais/licenciadas ou autorização dos titulares para publicação.
