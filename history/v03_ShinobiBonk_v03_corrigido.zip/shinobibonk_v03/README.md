# ShinobiBonk v0.3 — Protótipo local

Abra `index.html` no Chrome ou Edge desktop. Sem dependências externas, servidor ou instalação. Os personagens são representações geométricas pixeladas **provisórias**, não sprites oficiais. O jogo é uma arena 2D com câmera rotacionável, **não um jogo 3D**. Os gráficos e sistemas foram criados para avaliação de mecânicas, não para publicação comercial.

## Controles

- WASD: movimentar; clique no canvas para capturar o mouse e girar a câmera; Esc libera o mouse.
- Espaço: pular; Shift: esquiva com invulnerabilidade curta; E: interação próxima.
- 1–4: ativar jutsus quando disponíveis; 4 exige desbloqueio persistente.
- R: Ultimate manual (100 Chakra); Y: alternar Ultimate automática; P: pausar.

## Conteúdo implementado

- Naruto, Gaara, Madara e Hashirama com atributos, passivas simplificadas, 4 técnicas e Ultimate.
- Hordas escaláveis, danos físicos e elementais, crítico, queimadura DoT, congelamento, paralisia e lentidão.
- XP, níveis, Ryō, Chakra e drops; sorte e 5 raridades; 24 itens e 13 pílulas.
- Planejador de pool com itens planejados/arquivados; persistência local em `localStorage`.
- Sapo Sábio (escolha de buffs), Marca de Orochimaru (nível + dificuldade + item), caça-níquel (pode dar dano/perda ou recompensa), treinamento de Guy.
- Três estágios e Kyūbi final, relatório com dano por habilidade e build.
- Desbloqueio persistente do quarto slot por 300 Ryō e dificuldades sequenciais.

## Limitações verificadas no código (não testadas no navegador)

- **Sem multiplayer, clãs, rankings online, backend, fusões, Shisui, mapas procedurais completos ou modelos 3D.**
- **Metas de 240 FPS e 1.400 inimigos não validadas**. A colisão de projéteis usa grade espacial, mas a simulação e o desenho de muitos inimigos podem ser limitantes.
- Dificuldades são desbloqueadas localmente. O jogo pode ter desequilíbrios e bugs; necessita playtesting.
- Estágios acelerados para testes: 90 s cada + 90 s para Kyūbi. Design final: 10 min cada + 10 min chefe.
- Os efeitos de buffs são permanentes durante a run, com exceção do Saquê lendário. O jogo não tem sistema de fusão ainda.
- Não usar artes ou personagens protegidos em distribuição pública sem avaliar licenças e direitos.

## Como testar

1. Abra `index.html` em navegador desktop.
2. Clique `Nova partida` ou use o botão no menu inicial.
3. Aproximar-se de um NPC e apertar `E`.
4. Suba níveis para testar sorte, raridades e o pool; visite o planejador antes da próxima partida.
5. Complete estágios e derrote Kyūbi; verifique o relatório e o Ryō persistente.

## Registro de decisões

Consulte `docs/ESPECIFICACAO.md` para requisitos e pendências. A v0.3 é uma **fatia vertical jogável**, não o jogo final.
