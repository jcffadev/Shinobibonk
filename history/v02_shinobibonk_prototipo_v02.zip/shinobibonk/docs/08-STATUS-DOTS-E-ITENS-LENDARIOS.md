# Status, dano periódico e itens lendários — v0.2

## Requisitos
- Dano periódico (DoT) é dano por segundo (DPS) aplicado ao longo do tempo; não confundir as duas métricas.
- Fogo: queimadura, dano periódico. Madeira: veneno experimental, dano periódico.
- Água/Vento: chance de congelamento (adaptação de gameplay; revisar posteriormente para técnicas de gelo/Hyou­ton). Raio: paralisia. Terra/Madeira: lentidão.
- Status devem ter duração, chance de aplicação, imunidades e regras de acumulação configuráveis por habilidade.
- Taijutsu é ataque normal/físico e recebe modificadores globais, de ataque e específicos de Taijutsu.
- Equipamentos devem permitir aumento de dano, área, projéteis, duração, recarga, crítico, chance de status, XP, moedas e coleta.

## Saquê lendário / estilo Punho Bêbado
- Item inspirado no estilo de combate do Rock Lee, representado por um item fictício de jogo, não incentivo ao consumo real.
- **Inimigos:** desorientação reduz velocidade de deslocamento por 4 segundos (primeira aproximação de protótipo).
- **Jogador:** +35% dano multiplicativo, +25% movimento, +25% velocidade de ataque e +18 pontos percentuais de esquiva por 15 segundos.
- Obtido como drop raro e de chefes; itens visíveis em roxo no mapa.
- Valores são provisórios e devem ser balanceados. Futuramente, Lee terá sinergia passiva única com o item, sem tornar o item inútil aos demais.
- Drops de chefes são garantidos nesta fatia vertical apenas para facilitar testes; economia definitiva será diferente.

## Fórmula provisória
Dano por hit = base × (1 + bônus aditivos) × produto dos multiplicadores [x] × vantagem elemental × crítico × bônus temporários.
DoT é aplicado em ticks de simulação, independentemente da quantidade de partículas e textos desenhados.

## Estado de implementação
Implementado no protótipo local v0.2: saquê raro, buffs temporários, desorientação de inimigos próximos, queimadura, veneno, congelamento, paralisia, upgrades de DoT, congelamento, velocidade de ataque e esquiva. Ainda não implementados: interface de inventário, efeitos individuais de todas as técnicas, balanceamento por personagem, multiplayer e validação de performance de 240 FPS.
